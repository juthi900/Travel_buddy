package com.example.tbuddy.Prev;

import com.example.tbuddy.Model.Users;

public class Prevs {

    private static Users current;
}
