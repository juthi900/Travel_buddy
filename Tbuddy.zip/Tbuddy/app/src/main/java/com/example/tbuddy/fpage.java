package com.example.tbuddy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class fpage extends AppCompatActivity implements View.OnClickListener{
    private Button b1, b2;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fpage);

        b1 = findViewById(R.id.btn1);
        b2 = findViewById(R.id.btn2);
  b1.setOnClickListener(this);
        b2.setOnClickListener(this);
    }

    public void onClick(View v) {
        if (v.getId() == R.id.btn1) {
            Intent intent = new Intent(fpage.this, regster.class);
            startActivity(intent);

        } else if (v.getId() == R.id.btn2) {
            Intent intent = new Intent(fpage.this, login.class);
            startActivity(intent);

        }
    }
}





