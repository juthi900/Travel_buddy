package com.example.tbuddy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.tbuddy.Model.Users;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class login extends AppCompatActivity {
private EditText pass,phone;
private Button login;
private TextView adm,nadmn;
private String parentdbname="Users";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login=(Button)findViewById(R.id.logb);
        adm=(TextView) findViewById(R.id.admin);
        nadmn=(TextView) findViewById(R.id.nadmin);
        phone=(EditText) findViewById(R.id.loginphne);
        pass=(EditText) findViewById(R.id.loginpass);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
loguser();
            }
        });

adm.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        login.setText("Login admin");
        adm.setVisibility(View.INVISIBLE);
        nadmn.setVisibility(View.VISIBLE);
        parentdbname="Admins";
    }
});
nadmn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        login.setText("Login ");
        adm.setVisibility(View.VISIBLE);
        nadmn.setVisibility(View.INVISIBLE);
        parentdbname="Users";
    }
});


    }

















    private void loguser(){
        String pne = phone.getText().toString();
        String passwd = pass.getText().toString();
 if (TextUtils.isEmpty(pne)) {

            Toast.makeText(this, "Please write your phne", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(passwd)) {

            Toast.makeText(this, "Please write your pass", Toast.LENGTH_SHORT).show();
        } else {

           Allowaccess(pne,passwd);


        }
    }

    private void Allowaccess(String pne, String passwd) {

        final DatabaseReference RootRef;
        RootRef= FirebaseDatabase.getInstance().getReference();
RootRef.addListenerForSingleValueEvent(new ValueEventListener() {
    @Override
    public void onDataChange(@NonNull DataSnapshot snapshot) {
        if (snapshot.child(parentdbname).child(pne).exists()) {

            Users user=snapshot.child(parentdbname).child(pne).getValue(Users.class);

if(user.getPne().equals(pne)){
    if(user.getPasswd().equals(passwd)){
        Toast.makeText(login.this, "Login success", Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(login.this,home.class);
        startActivity(intent);
    }

}

        } else {

            Toast.makeText(login.this, "Account"+pne+"does not exits", Toast.LENGTH_SHORT).show();







        }
    }
    @Override
    public void onCancelled(@NonNull DatabaseError error) {

    }
});

    }


}

